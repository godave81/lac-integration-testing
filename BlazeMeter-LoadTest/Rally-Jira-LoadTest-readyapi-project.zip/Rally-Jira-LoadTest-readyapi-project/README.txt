
===== Script Converter: Go from LoadRunner to Open Source =====

BlazeMeter is a platform for load and performance testing that enables dev and QA teams to run scalable and continuous testing for website, mobile, api and software.

shifleft.blazemeter.com translates your LoadRunner scripts to Taurus (https://gettaurus.org), currently supporting most HTTP requests and flow control sentences and assertions; takes your TruClient script and converts it into a Selenium script, including most commonly used functions such as navigate, wait, click, send text and select from combobox.

The converter can handle data file parametrization and as well as support configuration conversions such as run tree, time out, and think time.

After converting your Load Runner or TruClient script, you will receive a yaml file and all the needed additional files to run it straight on Taurus or upload it into BlazeMeter.

The Taurus tool is an Open Source test automation framework, providing a simple YAML-based configuration format with DSL, executed through the command-line and scalable through cloud resource providers (with Blazemeter.com). It uses JMeter or Selenium as a generator and perfectly fits into Jenkins CI.

- If your LoadRunner script is HTTP (HTML or URL), the converter will generate a Taurus script (.yaml file) that uses JMeter as an executor. You can open a .yaml file with any text editor to review your script. When running that file in Taurus, Taurus will generate a JMX (JMeter file) and will run it for you. You can also use JMeter to edit the already generated JMX file.

- If your LoadRunner script is TruClient, the converter will generate a Taurus script (.yaml file), which will use Selenium as an executor. You can edit your selenium script (.py file) in your favorite Python IDE.

After your script is converted, you can see the results in BlazeMeter. Once in BlazeMeter, you can either run your new script in the cloud (by pressing the green play button), or you can download your .ZIP file to review your results.

===== Files in the zip folder =====

.- README.txt: this file
.- <TestCaseName>.yaml: This is the Taurus test script
.- *.groovy: This files are different functions that your script can or cannot use to resolve some tasks (for example: getResponseSize.groovy to load in a variable the body response size)
.- *.csv: all the data input files used in the scripts
.- summary.json and <TestCaseName>.usr.yaml_summary.json:
.- Your JMeter or Selenium scripts/test_requests.py: Python with selenium commands. Only available if the original script is a TruClient script
.- Your JMeter or Selenium scripts/requests.jmx: JMeter script. Only available if the original script is a HTTP (Html or Url) script

===== Currently not supported =====

Functions like data base connection, file handling, math functions, string handling or datetime functions are in the roadmap for including in the conversions support. Also, at this time, we are not supporting concurrent samples, meaning we don't support running multiple samples in parallel. If your script contains these functions, please request personalized assistance to shiftleft@blazemeter.com, and a member of the support team will contact you within one business day.

===== What you will find in the .yaml =====

This will be the main execution point of Taurus, if there are any syntax errors this is the place they hide. If there is any functionality that is essential to your script that the converter missed, this is where you should implement them.

To facilitate the transition to open source load testing, we leave Warnings, Information, Notes, and even the comments from the original script. It is essential for the user to verify that all core functions are converted properly. Otherwise you could be getting 400 on the response.

===== Resources =====

http://jmeter.apache.org/
The Apache JMeter™ application is an open source software, a 100% pure Java application designed to load test functional behavior and measure performance. It was originally designed for testing Web Applications but has since expanded to other test functions.

http://www.seleniumhq.org/
Selenium has the support of some of the largest browser vendors who have taken (or are taking) steps to make Selenium a native part of their browser. It is also the core technology in countless other browser automation tools, APIs and frameworks.

===== Terms of Services =====

By having submitted your email, you have agreed to our Terms of Services (http://blazemeter.com/terms-service)